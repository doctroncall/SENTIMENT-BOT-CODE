# Cursor SMC Trading Bot

A production-ready Smart Money Concepts (SMC) trading bot for MetaTrader 5 on Windows.

## Quick Start (5 Minutes)

### 1. Install (2 minutes)
```
Double-click: install.bat
```

### 2. Configure (2 minutes)
Edit `config/config.yaml`:
```yaml
trading:
  symbols: ["EURUSD", "GBPUSD"]  # Your symbols
  timeframe: "H1"                # Your timeframe
  lot_size: 0.01                 # Your lot size
  risk_percent: 1.0              # Risk per trade (1% recommended)
```

### 3. Test Connection (30 seconds)
```
Double-click: test_connection.bat
```
You should see "SUCCESS: Connected to MT5!"

### 4. Start Trading (30 seconds)
```
Double-click: start.bat
```

**That's it!** The bot is now running. Press `Ctrl+C` to stop.

---

## Features

- **MT5 Integration**: Seamless connection to MetaTrader 5 terminal
- **Smart Money Concepts Analysis**:
  - Market Structure identification (bullish/bearish/ranging)
  - Order Blocks (OB) detection
  - Fair Value Gaps (FVG) identification
  - Swing points analysis
- **Automated Trading**: Execute trades based on SMC strategy
- **Risk Management**: Position sizing based on account risk percentage
- **Multi-Symbol Support**: Trade multiple currency pairs simultaneously
- **Comprehensive Logging**: Track all bot activities and decisions
- **Windows Optimized**: Easy-to-use batch files for Windows users

## Requirements

- Windows 10/11
- Python 3.8 or higher
- MetaTrader 5 terminal installed
- Active MT5 account (demo or live)

## Installation

1. **Clone or download this repository** to your Windows machine

2. **Run the installation script**:
   ```
   install.bat
   ```
   This will:
   - Create a Python virtual environment
   - Install all required dependencies
   - Set up the project structure

3. **Configure the bot**:
   - Open `config/config.yaml` in a text editor
   - Update the settings according to your needs:
     - MT5 account credentials (optional - can use current logged-in account)
     - Trading symbols (e.g., EURUSD, GBPUSD, XAUUSD)
     - Timeframe (M1, M5, M15, M30, H1, H4, D1, W1)
     - Risk management parameters
     - Scan interval

## Configuration

### MT5 Settings
```yaml
mt5:
  account: null          # Leave null to use current MT5 terminal
  password: null         # Or provide credentials for auto-login
  server: null
```

### Trading Settings
```yaml
trading:
  symbols:               # Symbols to trade
    - "EURUSD"
    - "GBPUSD"
    - "USDJPY"
  
  timeframe: "H1"       # Trading timeframe
  lot_size: 0.01        # Default lot size
  max_positions: 3      # Maximum simultaneous positions
  risk_percent: 1.0     # Risk per trade (% of balance)
  risk_reward: 2.0      # Risk:Reward ratio (1:2)
  scan_interval: 300    # Seconds between scans
```

### SMC Settings
```yaml
smc:
  swing_lookback: 10    # Candles to look back for swing points
  fvg_min_gap: 0.0001  # Minimum gap size for FVGs
```

## Usage

### Starting the Bot
1. Ensure MetaTrader 5 is running and logged in
2. Double-click `start.bat`
3. The bot will connect to MT5 and start scanning symbols
4. Press `Ctrl+C` to stop

### Monitor Activity
- **Console**: Real-time logs displayed in the window
- **Log File**: Check `logs/smc_bot.log` for detailed history
- **MT5 Terminal**: View executed trades in MT5

## How It Works

### 1. Market Analysis
The bot analyzes each configured symbol using SMC principles:
- Identifies swing highs and swing lows
- Determines overall market structure (bullish/bearish/ranging)
- Detects order blocks (institutional buying/selling zones)
- Identifies fair value gaps (imbalances in price)

### 2. Signal Generation
Trading signals are generated when:
- Market shows clear structure (bullish or bearish)
- Price approaches a key SMC zone (order block or FVG)
- Risk:reward ratio meets criteria

### 3. Trade Execution
When a signal is generated:
- Position size is calculated based on risk percentage
- Stop loss is placed beyond recent swing point
- Take profit is set according to risk:reward ratio
- Order is sent to MT5 for execution

### 4. Position Management
The bot monitors open positions and can:
- Track position status
- Manage trailing stops (can be customized)
- Close positions based on criteria

## Project Structure

```
cursor-smc/
├── config/
│   └── config.yaml          # Configuration file
├── src/
│   ├── mt5_connector.py     # MT5 connection handler
│   ├── smc_analyzer.py      # SMC analysis engine
│   ├── trading_bot.py       # Main trading bot logic
│   ├── config_manager.py    # Configuration management
│   └── logger_setup.py      # Logging setup
├── logs/                    # Log files (created automatically)
├── data/                    # Data storage (optional)
├── main.py                  # Main entry point
├── requirements.txt         # Python dependencies
├── install.bat             # Installation script
├── start.bat               # Start bot script
├── test_connection.bat     # MT5 connection test
└── README.md               # This file
```

## Safety & Disclaimer

⚠️ **IMPORTANT WARNINGS**:

1. **Start with a Demo Account**: Always test with a demo account first
2. **Risk Management**: Never risk more than you can afford to lose
3. **Monitor Regularly**: Check the bot's performance regularly
4. **Market Conditions**: The bot works best in trending markets
5. **No Guarantees**: Past performance does not guarantee future results

**This bot is provided as-is with no guarantees of profitability. Trading involves substantial risk of loss. Use at your own risk.**

## Customization

All trading parameters are in `config/config.yaml`:
- Symbols to trade
- Timeframe
- Lot sizes
- Risk management settings
- SMC analysis parameters

For advanced customization:
- `src/smc_analyzer.py` - Strategy logic
- `src/trading_bot.py` - Trading execution
- `src/mt5_connector.py` - MT5 integration

## Troubleshooting

### Bot won't connect to MT5
- Ensure MT5 terminal is running
- Check that MetaTrader 5 is properly installed
- Try running `test_connection.bat` for diagnostics
- Verify Python has permissions to access MT5

### No trading signals
- Check that symbols are available in your MT5 account
- Verify timeframe has enough historical data
- Review SMC parameters in config.yaml
- Check logs for analysis details

### Installation errors
- Ensure Python 3.8+ is installed
- Run `install.bat` as Administrator if permission errors occur
- Check internet connection for pip downloads

## Support

For issues, questions, or improvements:
1. Check the logs in `logs/smc_bot.log`
2. Review the configuration in `config/config.yaml`
3. Test MT5 connection with `test_connection.bat`

## License

This project is provided as-is for educational and research purposes.

## Version

Version: 1.0.0
Last Updated: 2025-10-20
